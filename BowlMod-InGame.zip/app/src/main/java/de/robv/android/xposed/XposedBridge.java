package de.robv.android.xposed;

import java.lang.reflect.Member;

public final class XposedBridge {
    public static void log(String s) { android.util.Log.i("BowlMod", s); }
    public static void log(Throwable t) { android.util.Log.e("BowlMod", "err", t); }
    public static Object hookMethod(Member m, XC_MethodHook cb) { return null; }
}
