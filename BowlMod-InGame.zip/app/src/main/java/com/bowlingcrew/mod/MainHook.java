package com.bowlingcrew.mod;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_LoadPackage;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

import android.app.Activity;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TARGET = "com.tetrox.bowl";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) throws Throwable {
        if (lp.packageName == null || !lp.packageName.startsWith(TARGET)) return;

        try {
            XposedHelpers.findAndHookMethod(Activity.class, "onResume",
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam p) {
                            Object o = p.thisObject;
                            if (!(o instanceof Activity)) return;
                            final Activity a = (Activity) o;
                            if (!a.getPackageName().startsWith(TARGET)) return;
                            try {
                                BotMenu.attach(a);
                            } catch (Throwable t) {
                                XposedBridge.log(t);
                            }
                        }
                    });
        } catch (Throwable t) {
            XposedBridge.log(t);
        }
    }
}
