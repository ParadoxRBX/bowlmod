package com.bowlingcrew.mod;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Switch;
import android.widget.TextView;

/**
 * In-game overlay: reticle, dot and panel, injected into the activity's decor.
 *
 * Geometry is all fractions of the measured screen, so any phone behaves alike.
 */
public final class BotMenu {

    private static final long BEAT = 4500;
    private static final float GRAB_Y = 0.80f;
    private static final float RELEASE_Y = 0.32f;
    private static final float POCKET = 0.545f;
    private static final float ANGLE = 0.035f;

    private static BotMenu sInstance;

    private final Activity act;
    private final ViewGroup decor;
    private final View target;
    private final Handler ui = new Handler(Looper.getMainLooper());

    boolean autoAim = true;
    boolean autoShot;
    int trim;

    private Line line;
    private View dot;
    private View panel;
    private TextView state;
    private long busyUntil;

    private BotMenu(Activity a, ViewGroup d, View t) {
        act = a;
        decor = d;
        target = t;
    }

    static void attach(Activity a) {
        BotMenu cur = sInstance;
        if (cur != null && cur.act == a) return;

        View d = a.getWindow().getDecorView();
        if (!(d instanceof ViewGroup)) return;
        ViewGroup g = (ViewGroup) d;
        if (g.getChildCount() == 0) return;

        sInstance = new BotMenu(a, g, g.getChildAt(0));
        sInstance.install();
    }

    // ------------------------------------------------------------ install

    private void install() {
        line = new Line(act, this);
        decor.addView(line, new ViewGroup.LayoutParams(-1, -1));

        dot = new View(act);
        dot.setBackgroundResource(R.drawable.fab_bg);
        android.widget.FrameLayout.LayoutParams flp =
                new android.widget.FrameLayout.LayoutParams(dp(44), dp(44));
        flp.gravity = Gravity.TOP | Gravity.END;
        flp.topMargin = dp(110);
        flp.rightMargin = dp(6);
        decor.addView(dot, flp);
        dot.setOnTouchListener(new DotTouch());
        dot.setAlpha(0.55f);

        ui.post(loop);
    }

    private abstract class SimpleSeek implements android.widget.SeekBar.OnSeekBarChangeListener {
        public void onStartTrackingTouch(android.widget.SeekBar s) { }
        public void onStopTrackingTouch(android.widget.SeekBar s) { }
    }

    private void openPanel() {
        if (panel != null) return;

        Context c = new ContextThemeWrapper(act, R.style.PanelTheme);
        panel = LayoutInflater.from(c).inflate(R.layout.panel, null);

        android.widget.FrameLayout.LayoutParams lp =
                new android.widget.FrameLayout.LayoutParams(dp(260), -2);
        lp.gravity = Gravity.TOP | Gravity.END;
        lp.topMargin = dp(164);
        lp.rightMargin = dp(6);

        state = panel.findViewById(R.id.txtState);
        panel.findViewById(R.id.btnClose).setOnClickListener(v -> closePanel());

        final Switch aim = panel.findViewById(R.id.swAim);
        aim.setChecked(autoAim);
        aim.setOnCheckedChangeListener((b, on) -> {
            autoAim = on;
            paint();
        });

        final Switch shot = panel.findViewById(R.id.swShot);
        shot.setChecked(autoShot);
        shot.setOnCheckedChangeListener((b, on) -> {
            autoShot = on;
            paint();
        });

        panel.findViewById(R.id.btnLeft).setOnClickListener(v -> {
            trim = Math.max(-15, Math.min(15, trim - 1));
            paint();
        });
        panel.findViewById(R.id.btnRight).setOnClickListener(v -> {
            trim = Math.max(-15, Math.min(15, trim + 1));
            paint();
        });
        panel.findViewById(R.id.btnReset).setOnClickListener(v -> {
            trim = 0;
            paint();
        });
        panel.findViewById(R.id.btnOnce).setOnClickListener(v -> fire());

        decor.addView(panel, lp);
        paint();
    }

    private void closePanel() {
        if (panel == null) return;
        decor.removeView(panel);
        panel = null;
        state = null;
    }

    private class DotTouch implements View.OnTouchListener {
        private float dy;
        private int start;
        private boolean moved;

        public boolean onTouch(View v, MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    dy = e.getRawY();
                    start = ((ViewGroup.MarginLayoutParams) v.getLayoutParams()).topMargin;
                    moved = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (Math.abs(e.getRawY() - dy) > dp(10)) moved = true;
                    ViewGroup.MarginLayoutParams lp =
                            (ViewGroup.MarginLayoutParams) v.getLayoutParams();
                    lp.topMargin = start + (int) (e.getRawY() - dy);
                    v.setLayoutParams(lp);
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!moved) {
                        if (panel == null) openPanel(); else closePanel();
                    }
                    return true;
                default:
                    return true;
            }
        }
    }

    // ------------------------------------------------------------ geometry

    int dp(float v) {
        return Math.round(v * act.getResources().getDisplayMetrics().density);
    }

    private int[] screen() {
        DisplayMetrics dm = new DisplayMetrics();
        act.getWindowManager().getDefaultDisplay().getRealMetrics(dm);
        return new int[]{Math.min(dm.widthPixels, dm.heightPixels),
                Math.max(dm.widthPixels, dm.heightPixels)};
    }

    private float aimX(int w) {
        return w * (POCKET + trim / 100f);
    }

    private void paint() {
        int[] s = screen();
        float x = aimX(s[0]);
        float y1 = s[1] * GRAB_Y;
        float y2 = s[1] * RELEASE_Y;
        if (line != null) line.show(x, y1, x + s[0] * ANGLE, y2, autoAim || autoShot);
        if (state != null) state.setText("aim " + Math.round(x * 100f / s[0]) + "%");
    }

    // ------------------------------------------------------------ loop

    private final Runnable loop = new Runnable() {
        public void run() {
            paint();
            if (autoShot && System.currentTimeMillis() > busyUntil) fire();
            ui.postDelayed(this, BEAT);
        }
    };

    void fire() {
        if (System.currentTimeMillis() < busyUntil) return;
        int[] s = screen();
        float x1 = aimX(s[0]);
        float y1 = s[1] * GRAB_Y;
        float x2 = x1 + s[0] * ANGLE;
        float y2 = s[1] * RELEASE_Y;

        busyUntil = System.currentTimeMillis() + 1200;
        if (state != null) state.setText("throwing");
        Touch.throwLine(target, x1, y1, x2, y2, ui, null);
    }

    // ------------------------------------------------------------ reticle

    static final class Line extends View {
        private final BotMenu m;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float x1, y1, x2, y2;
        private boolean on;

        Line(Context c, BotMenu m) {
            super(c);
            this.m = m;
            setClickable(false);
        }

        void show(float a, float b, float c2, float d, boolean visible) {
            x1 = a;
            y1 = b;
            x2 = c2;
            y2 = d;
            on = visible;
            invalidate();
        }

        protected void onDraw(Canvas c) {
            if (!on) return;
            float r = m.dp(16);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(m.dp(2));
            p.setColor(0xFF00E5FF);
            c.drawCircle(x1, y1, r, p);
            p.setColor(0x6600E5FF);
            p.setStrokeWidth(m.dp(3));
            c.drawLine(x1, y1, x2, y2, p);
            c.drawCircle(x2, y2, m.dp(9), p);
        }
    }
}
