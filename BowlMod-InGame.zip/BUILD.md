# Build the module

1. New public GitHub repo.
2. **Add file → Upload files** → drag `BowlMod-InGame.zip`. Commit.
3. `.github/workflows/build.yml` → pencil → keep as is.
4. **Actions → build → Run workflow**.
5. Green tick → **Artifacts** → `BowlMod-apk` → unzip.

Output is `app-debug.apk` — that is the module. Install it, then follow the README.
