# BowlMod 7 — menu inside the game (LSPatch, no root)

One APK. The mod menu lives *inside* Bowling Crew and pushes touches directly
into the game's view instead of going through the accessibility gesture API.

- No separate app, no accessibility service for throwing.
- Touches are synced MotionEvents on the UI thread: exact timing, no 100 ms jitter,
  nothing to cancel them.
- Two switches. Auto Aim, Auto Shot. Plus `<` `>` trim.

## Before you start — do this now

In Bowling Crew: link the account to Google Play. The patched APK is re-signed, so
the old install must be removed and an unlinked local save goes with it.

## You need

- **LSPatch** — github.com/JingMatrix/LSPatch/releases
- **SAI** (Split APKs Installer) — for the XAPK
- The game's XAPK (APKPure or APKMirror)
- ~2 GB free storage

## Steps

1. Build the module (see `BUILD.md`) and install the APK.
2. Install SAI, download the Bowling Crew **XAPK**.
3. Uninstall the Play Store copy of Bowling Crew.
4. SAI → **Install APKs** → pick the XAPK → install all splits.
5. Open **LSPatch** → **+** → *Select installed app* → Bowling Crew.
6. Mode: **Local** (patch in place).
7. **Embed module** → tick **Bowling Mod** → **Start patch**.
8. When it finishes, install the patched result and launch it.

Steps 5–8 redo after every game update.

## Use

A blue dot appears in the game. Tap it.

- **Auto Aim** — draws the line
- **Auto Shot** — throws, on a beat
- `<` `>` — shift the line 1%, saved

## Why this should throw when the last one didn't

`dispatchGesture` is queued by the system and is silently cancelled if anything
else touches the screen or the service loses focus. Here the events are handed to
the game's own view directly, in order, on its UI thread — same as a finger.

## Honest limits

Still blind: one pocket line, no pin reading. Curved lanes need the trim. Full
power always.

If it throws but goes wide, trim. If it throws nothing at all, the grab point is
wrong for your screen — tell me, it's one constant.
